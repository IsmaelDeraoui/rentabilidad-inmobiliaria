# ¿Me sale rentable? — MVP
Calculadora gratuita de análisis de inversión inmobiliaria.

## Monetización prevista
1. Tráfico orgánico/SEO.
2. Afiliación de hipotecas, seguros y servicios relacionados (cuando se habiliten acuerdos).
3. Informe premium descargable y comparador de operaciones en una segunda versión.
4. Publicidad cuando haya suficiente tráfico.

## Publicación
El MVP está preparado como sitio estático. Puede desplegarse en Vercel, Netlify o GitHub Pages.
